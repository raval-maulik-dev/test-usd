<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class QuizController extends Controller
{
    public function start()
    {
        if (!session('user_data')) {
            return redirect()->route('register');
        }

        $questions = $this->getQuizQuestions();
        session(['quiz_questions' => $questions, 'quiz_started' => true, 'current_question' => 0]);

        return view('quiz.start');
    }

    public function getQuestion($id)
    {
        $questions = session('quiz_questions', []);
        
        if (isset($questions[$id])) {
            return response()->json($questions[$id]);
        }

        return response()->json(['error' => 'Question not found'], 404);
    }

    public function submitAnswer(Request $request)
    {
        $currentQuestion = $request->question_id;
        $selectedAnswer = $request->answer;
        $timeTaken = $request->time_taken;

        // Store answer in session
        $answers = session('quiz_answers', []);
        $answers[$currentQuestion] = [
            'answer' => $selectedAnswer,
            'time_taken' => $timeTaken,
            'is_correct' => $this->checkAnswer($currentQuestion, $selectedAnswer)
        ];
        session(['quiz_answers' => $answers]);

        return response()->json(['success' => true]);
    }

    public function results()
    {
        $answers = session('quiz_answers', []);
        $questions = session('quiz_questions', []);
        
        $score = 0;
        $totalTime = 0;
        $fastAnswers = 0;

        foreach ($answers as $questionId => $answer) {
            if ($answer['is_correct']) {
                $score += 5; // +5 for correct answer
                if ($answer['time_taken'] <= 5) {
                    $score += 2; // +2 for fast answer
                    $fastAnswers++;
                }
            }
            $totalTime += $answer['time_taken'];
        }

        $correctAnswers = array_sum(array_column($answers, 'is_correct'));
        $percentage = ($correctAnswers / count($questions)) * 100;

        // Determine message based on score
        $message = $this->getResultMessage($correctAnswers);
        $badge = $this->getBadge($correctAnswers);

        $results = [
            'score' => $score,
            'correct_answers' => $correctAnswers,
            'total_questions' => count($questions),
            'percentage' => round($percentage, 1),
            'total_time' => $totalTime,
            'fast_answers' => $fastAnswers,
            'message' => $message,
            'badge' => $badge
        ];

        session(['quiz_results' => $results]);

        return view('quiz.results', compact('results'));
    }

    public function certificate($id)
    {
        $userData = session('user_data');
        $results = session('quiz_results');
        
        if (!$userData || !$results) {
            return redirect()->route('home');
        }

        return view('certificate', compact('userData', 'results'));
    }

    private function getQuizQuestions()
    {
        return [
            [
                'id' => 1,
                'question' => 'Which of these is an Indian product?',
                'options' => [
                    ['image' => 'tata-tea.jpg', 'text' => 'Tata Tea', 'is_indian' => true],
                    ['image' => 'lipton.jpg', 'text' => 'Lipton', 'is_indian' => false],
                    ['image' => 'tetley.jpg', 'text' => 'Tetley', 'is_indian' => false],
                    ['image' => 'brooke-bond.jpg', 'text' => 'Brooke Bond', 'is_indian' => false]
                ]
            ],
            [
                'id' => 2,
                'question' => 'Identify the Indian smartphone brand:',
                'options' => [
                    ['image' => 'micromax.jpg', 'text' => 'Micromax', 'is_indian' => true],
                    ['image' => 'samsung.jpg', 'text' => 'Samsung', 'is_indian' => false],
                    ['image' => 'apple.jpg', 'text' => 'Apple', 'is_indian' => false],
                    ['image' => 'xiaomi.jpg', 'text' => 'Xiaomi', 'is_indian' => false]
                ]
            ],
            // Add 18 more questions...
            [
                'id' => 20,
                'question' => 'Which is the Indian automobile company?',
                'options' => [
                    ['image' => 'mahindra.jpg', 'text' => 'Mahindra', 'is_indian' => true],
                    ['image' => 'toyota.jpg', 'text' => 'Toyota', 'is_indian' => false],
                    ['image' => 'honda.jpg', 'text' => 'Honda', 'is_indian' => false],
                    ['image' => 'hyundai.jpg', 'text' => 'Hyundai', 'is_indian' => false]
                ]
            ]
        ];
    }

    private function checkAnswer($questionId, $selectedAnswer)
    {
        $questions = session('quiz_questions', []);
        if (isset($questions[$questionId])) {
            return $questions[$questionId]['options'][$selectedAnswer]['is_indian'] ?? false;
        }
        return false;
    }

    private function getResultMessage($correctAnswers)
    {
        if ($correctAnswers >= 18) {
            return 'Swadeshi Warrior! You are a true champion of Indian products!';
        } elseif ($correctAnswers >= 10) {
            return 'Good Start! Keep learning about Indian products!';
        } else {
            return 'Try Again! Explore more about Indian brands and products!';
        }
    }

    private function getBadge($correctAnswers)
    {
        if ($correctAnswers >= 18) {
            return 'warrior';
        } elseif ($correctAnswers >= 10) {
            return 'good';
        } else {
            return 'beginner';
        }
    }
}