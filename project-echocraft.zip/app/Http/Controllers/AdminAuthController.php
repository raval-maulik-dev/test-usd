<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AdminAuthController extends Controller
{
    public function showLogin()
    {
        return view('admin.login');
    }

    public function login(Request $request)
    {
        $credentials = [
            'admin@swadeshi.com' => 'admin123',
            'manager@swadeshi.com' => 'manager123',
            'supervisor@swadeshi.com' => 'supervisor123'
        ];

        $email = $request->email;
        $password = $request->password;

        if (isset($credentials[$email]) && $credentials[$email] === $password) {
            $adminUser = [
                'email' => $email,
                'name' => ucfirst(explode('@', $email)[0]),
                'role' => $email === 'admin@swadeshi.com' ? 'Super Admin' : 'Admin',
                'logged_in_at' => now()
            ];

            session(['admin_logged_in' => true, 'admin_user' => $adminUser]);
            return redirect()->route('admin.dashboard');
        }

        return back()->withErrors(['Invalid credentials']);
    }

    public function logout()
    {
        session()->forget(['admin_logged_in', 'admin_user']);
        return redirect()->route('admin.login');
    }
}