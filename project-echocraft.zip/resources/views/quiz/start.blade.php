@extends('layouts.app')

@section('title', 'Quiz - Swadeshi Abhiyan')

@section('content')
<div class="min-h-screen bg-gradient-to-br from-orange-50 via-white to-green-50" id="quizContainer">
    <!-- Quiz Header -->
    <div class="bg-white shadow-lg border-b border-orange-200 sticky top-16 z-40">
        <div class="max-w-4xl mx-auto px-4 py-4">
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-4">
                    <div class="w-12 h-12 tricolor-gradient rounded-full flex items-center justify-center">
                        <span class="text-gray-800 font-bold">SA</span>
                    </div>
                    <div>
                        <h1 class="text-xl font-bold text-gray-800">Swadeshi Quiz</h1>
                        <p class="text-sm text-gray-600">Test your knowledge of Indian products</p>
                    </div>
                </div>
                <div class="text-right">
                    <div class="text-2xl font-bold text-orange-600" id="questionCounter">1/20</div>
                    <div class="text-sm text-gray-600">Questions</div>
                </div>
            </div>
        </div>
    </div>

    <!-- Quiz Content -->
    <div class="max-w-4xl mx-auto px-4 py-8">
        <!-- Loading Screen -->
        <div id="loadingScreen" class="text-center">
            <div class="bg-white rounded-3xl shadow-2xl p-12 border border-orange-100">
                <div class="w-20 h-20 tricolor-gradient rounded-full flex items-center justify-center mx-auto mb-6 animate-spin">
                    <span class="text-gray-800 font-bold text-2xl">SA</span>
                </div>
                <h2 class="text-2xl font-bold text-gray-800 mb-4">Preparing Your Quiz...</h2>
                <p class="text-gray-600 mb-6">Loading 20 questions about Indian products</p>
                <div class="w-full bg-gray-200 rounded-full h-3">
                    <div class="bg-gradient-to-r from-orange-500 to-red-600 h-3 rounded-full animate-pulse" style="width: 100%"></div>
                </div>
            </div>
        </div>

        <!-- Quiz Question -->
        <div id="quizQuestion" class="hidden">
            <div class="bg-white rounded-3xl shadow-2xl border border-orange-100 overflow-hidden">
                <!-- Timer and Progress -->
                <div class="bg-gradient-to-r from-orange-500 to-red-600 p-6">
                    <div class="flex items-center justify-between text-white">
                        <div>
                            <h2 class="text-xl font-bold">Question <span id="currentQuestion">1</span></h2>
                            <p class="text-orange-100">Choose the Indian product</p>
                        </div>
                        <div class="text-center">
                            <div class="text-3xl font-bold" id="timer">10</div>
                            <div class="text-sm text-orange-100">seconds</div>
                        </div>
                    </div>
                    <div class="mt-4">
                        <div class="w-full bg-white/30 rounded-full h-2">
                            <div class="bg-white h-2 rounded-full transition-all duration-1000" id="timerBar" style="width: 100%"></div>
                        </div>
                    </div>
                </div>

                <!-- Question Content -->
                <div class="p-8">
                    <h3 class="text-2xl font-bold text-gray-800 mb-8 text-center" id="questionText">
                        Which of these is an Indian product?
                    </h3>

                    <!-- Answer Options -->
                    <div class="grid grid-cols-2 gap-6" id="answerOptions">
                        <!-- Options will be loaded dynamically -->
                    </div>
                </div>
            </div>

            <!-- Quiz Instructions -->
            <div class="mt-8 bg-gradient-to-r from-orange-50 to-green-50 rounded-2xl p-6 border border-orange-200">
                <div class="flex items-center space-x-4">
                    <div class="w-12 h-12 bg-white rounded-xl flex items-center justify-center shadow-md">
                        <svg class="w-6 h-6 text-orange-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                        </svg>
                    </div>
                    <div>
                        <h4 class="font-semibold text-gray-800">Quiz Instructions</h4>
                        <p class="text-sm text-gray-600">You have 10 seconds per question. Choose the Indian product from the 4 options. No going back once answered!</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Quiz Completed -->
        <div id="quizCompleted" class="hidden text-center">
            <div class="bg-white rounded-3xl shadow-2xl p-12 border border-green-100">
                <div class="w-20 h-20 bg-gradient-to-r from-green-500 to-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
                    <svg class="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                    </svg>
                </div>
                <h2 class="text-3xl font-bold text-gray-800 mb-4">Quiz Completed!</h2>
                <p class="text-gray-600 mb-8">Calculating your results...</p>
                <div class="w-full bg-gray-200 rounded-full h-3">
                    <div class="bg-gradient-to-r from-green-500 to-green-600 h-3 rounded-full animate-pulse" style="width: 100%"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.tricolor-gradient {
    background: linear-gradient(to right, #FF9933 33.33%, #FFFFFF 33.33%, #FFFFFF 66.66%, #138808 66.66%);
}

.option-card {
    transition: all 0.3s ease;
}

.option-card:hover {
    transform: scale(1.02);
    box-shadow: 0 10px 25px rgba(0,0,0,0.1);
}

.option-selected {
    border-color: #10B981 !important;
    background: linear-gradient(to br, #D1FAE5, #A7F3D0) !important;
}

.option-correct {
    border-color: #10B981 !important;
    background: linear-gradient(to br, #D1FAE5, #A7F3D0) !important;
}

.option-incorrect {
    border-color: #EF4444 !important;
    background: linear-gradient(to br, #FEE2E2, #FECACA) !important;
}
</style>

<script>
$(document).ready(function() {
    let currentQuestionIndex = 0;
    let questions = [];
    let answers = [];
    let timer;
    let timeLeft = 10;

    // Sample questions data
    questions = [
        {
            id: 1,
            question: "Which of these is an Indian product?",
            options: [
                {image: "tata-tea.jpg", text: "Tata Tea", is_indian: true},
                {image: "lipton.jpg", text: "Lipton", is_indian: false},
                {image: "tetley.jpg", text: "Tetley", is_indian: false},
                {image: "brooke-bond.jpg", text: "Brooke Bond", is_indian: false}
            ]
        },
        {
            id: 2,
            question: "Identify the Indian smartphone brand:",
            options: [
                {image: "micromax.jpg", text: "Micromax", is_indian: true},
                {image: "samsung.jpg", text: "Samsung", is_indian: false},
                {image: "apple.jpg", text: "Apple", is_indian: false},
                {image: "xiaomi.jpg", text: "Xiaomi", is_indian: false}
            ]
        }
        // Add more questions as needed
    ];

    // Initialize quiz
    setTimeout(function() {
        $('#loadingScreen').addClass('hidden');
        $('#quizQuestion').removeClass('hidden');
        loadQuestion(0);
        startTimer();
    }, 2000);

    function loadQuestion(index) {
        if (index >= questions.length) {
            completeQuiz();
            return;
        }

        const question = questions[index];
        $('#currentQuestion').text(index + 1);
        $('#questionCounter').text((index + 1) + '/20');
        $('#questionText').text(question.question);

        let optionsHtml = '';
        question.options.forEach((option, optionIndex) => {
            optionsHtml += `
                <div class="option-card bg-gray-50 rounded-2xl p-6 border-2 border-gray-200 cursor-pointer hover:border-orange-400 transition-all duration-300" 
                     data-option="${optionIndex}" data-is-indian="${option.is_indian}">
                    <div class="w-full h-32 bg-gray-200 rounded-xl mb-4 flex items-center justify-center">
                        <span class="text-gray-700 font-bold text-lg">${option.text}</span>
                    </div>
                    <p class="text-center font-semibold text-gray-800">Option ${String.fromCharCode(65 + optionIndex)}</p>
                </div>
            `;
        });
        
        $('#answerOptions').html(optionsHtml);

        // Add click handlers
        $('.option-card').click(function() {
            if ($(this).hasClass('option-selected')) return;
            
            const selectedOption = $(this).data('option');
            const isCorrect = $(this).data('is-indian');
            
            selectAnswer(selectedOption, isCorrect);
        });
    }

    function startTimer() {
        timeLeft = 10;
        $('#timer').text(timeLeft);
        $('#timerBar').css('width', '100%');
        
        timer = setInterval(function() {
            timeLeft--;
            $('#timer').text(timeLeft);
            $('#timerBar').css('width', (timeLeft / 10 * 100) + '%');
            
            if (timeLeft <= 0) {
                clearInterval(timer);
                selectAnswer(-1, false); // Time up
            }
        }, 1000);
    }

    function selectAnswer(selectedOption, isCorrect) {
        clearInterval(timer);
        
        // Record answer
        answers.push({
            question_id: currentQuestionIndex,
            selected_option: selectedOption,
            is_correct: isCorrect,
            time_taken: 10 - timeLeft
        });

        // Show correct answer
        $('.option-card').each(function() {
            const isIndian = $(this).data('is-indian');
            if (isIndian) {
                $(this).addClass('option-correct');
            } else if ($(this).data('option') === selectedOption) {
                $(this).addClass('option-incorrect');
            }
        });

        // Move to next question after 2 seconds
        setTimeout(function() {
            currentQuestionIndex++;
            loadQuestion(currentQuestionIndex);
            startTimer();
        }, 2000);
    }

    function completeQuiz() {
        $('#quizQuestion').addClass('hidden');
        $('#quizCompleted').removeClass('hidden');
        
        // Submit quiz results
        setTimeout(function() {
            // Calculate results and redirect
            const correctAnswers = answers.filter(a => a.is_correct).length;
            const totalTime = answers.reduce((sum, a) => sum + a.time_taken, 0);
            
            // Redirect to results page
            window.location.href = '/quiz/results';
        }, 3000);
    }
});
</script>
@endsection